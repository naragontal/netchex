import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  NavLink
} from 'react-router-dom'
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import netchex_logo from '../assets/netchex_logo.png';
import locations_icon from '../assets/locations_icon.png';
import pay_schedules_icon from '../assets/pay_schedules_icon.png';
import earnings_icon from '../assets/earnings_icon.png';
import uploads_icon from '../assets/uploads_icon.png';
import helpful_tips_icon from '../assets/helpful_tips_icon.png';
import payroll_betty_icon from '../assets/payroll_betty_icon.png';
import phone_icon from '../assets/phone_icon.png';


import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

class Home extends Component {
  render(props) {
    return (
       <Grid>

         <div className="App" >
             <header className="App-header">
               <div className="App-title">
                  <img src={netchex_logo} className="App-logo" alt="logo" />
                     Company Setup
               </div>
             </header>
      <Grid>
       <Row className="show-grid">
        <Col lg={8} md={7} className="App-column-left-home">
         <div className="App-intro-title-left2"><br></br>
            {this.props.intro_title}
         </div>

         <div className="App-intro-left2">
           This setup is designed to help you blast off to a great start and fast-tract<br></br>
           your deployment in <b>4 simple steps.</b> Choose and item to begin.
         </div><br></br>

         <div className="grn-text-title">
            {this.props.text_title}
         </div>

      <Grid>
       <Row className="show-grid">
         <Col xs={4} md={3}>
         <div className="btn-blank-grntext"><br></br>
          <NavLink to="/locations" className="setup-text-icons">
            <img src={locations_icon} className="App-setup-icons"/></NavLink><br></br>
            <div className="grn-text">{this.props.setup_text_one}</div>
            <div className="App-small-text">{this.props.setup_subtext_one}</div><br></br>
         </div>
         </Col>
         <Col xs={3} md={3}>
         <div className="btn-blank-grntext"><br></br>
         <NavLink to="/pay_schedules" className="setup-text-icons">
           <img src={pay_schedules_icon} className="App-setup-icons" alt="Pay Schedules" /></NavLink><br></br>
           <div className="grn-text">{this.props.setup_text_two}</div>
           <div className="App-small-text">{this.props.setup_subtext_two}</div><br></br>
         </div>
         </Col>
         <Col xs={4} md={3}>
         <div className="btn-blank-grntext"><br></br>
           <NavLink to="/earnings" className="setup-text-icons">
             <img src={earnings_icon} className="App-setup-icons" alt="Earnings" /></NavLink><br></br>
             <div className="grn-text">{this.props.setup_text_three}</div>
             <div className="App-small-text">{this.props.setup_subtext_three}</div><br></br>
         </div>
         </Col>
         <Col xs={4} md={3}>
         <div className="btn-blank-grntext"><br></br>
           <NavLink to="/uploads" className="setup-text-icons">
             <img src={uploads_icon} className="App-setup-icons" alt="Uploads" /></NavLink><br></br>
             <div className="grn-text">{this.props.setup_text_four}</div>
             <div className="App-small-text">{this.props.setup_subtext_four}</div><br></br>
         </div>
         </Col>
       </Row>
      </Grid><br></br><br></br>
          <footer className="App-footer-center">
          <a href=" " className="setup-text-icons">
            <img src={phone_icon} className="App-phone-small" alt="Call us" /></a>
            <div className="App-small-text"><br></br>
               Once you complete the basic setup, you will<br></br>
               have the opportunity to schedule your kick off call.
            </div><br></br>
          </footer>
         </Col>
         <Col lg={3} md={3}>
           <div className="App-small-text-left"><br></br>
           <img src={helpful_tips_icon} className="App-helpful-tips" alt="Helpful tips" />
           <p className="App-small-text"><b>{this.props.helpful_tips_title}</b></p><br></br>
           <img src={payroll_betty_icon} className="App-betty2" alt="line" /><p className="App-small-text-left2">{this.props.betty_title}<br></br><br></br></p>
             <p className="App-small-text-left2">Hello, we are happy to be here to help guide<br></br>
                you through the setup process and offer tips<br></br>
                throughout the process to save time.<br></br><br></br>
                Remember to have these items ready<br></br>
                   to reference:<br></br>
                   <ul>
                      <li>Form #1</li>
                      <li>Form #2</li>
                      <li>Form #3</li>
                   </ul>
                   Great to have you aboard and lets get started!</p>
           </div>
         </Col>
        </Row>
       </Grid>
       </div>
      </Grid>
    );
   }
  }
   Home.propTypes = {
     title : PropTypes.string.isRequired,
     intro_title : PropTypes.string.isRequired,
     text_title : PropTypes.string.isRequired,
     setup_text_one : PropTypes.string.isRequired,
     setup_subtext_one : PropTypes.string.isRequired,
     setup_text_two : PropTypes.string.isRequired,
     setup_subtext_two : PropTypes.string.isRequired,
     setup_text_three : PropTypes.string.isRequired,
     setup_subtext_three : PropTypes.string.isRequired,
     setup_text_four : PropTypes.string.isRequired,
     setup_subtext_four : PropTypes.string.isRequired,
     helpful_tips_title : PropTypes.string.isRequired,
     betty_title : PropTypes.string.isRequired

  };

  Home.defaultProps = {
    title: "Company Setup",
    intro_title : "Up, Up, and Away!",
    text_title : "Basic Setup",
    setup_text_one : "Locations",
    setup_subtext_one : "0/2",
    setup_text_two : "Pay Schedules",
    setup_subtext_two : "0/2",
    setup_text_three : "Earnings",
    setup_subtext_three : "0/1",
    setup_text_four : "Uploads",
    setup_subtext_four : "0/4",
    helpful_tips_title : "Helpful Tips",
    betty_title : "Payroll Betty"
  };

  export default Home;
