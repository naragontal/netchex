import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  BrowserRouter as Router,
  Route,
  NavLink
} from 'react-router-dom'
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import netchex_logo from '../assets/netchex_logo.png';

import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

const Subheader = (props) => (
    <Grid>
          <subheader className="App-subheader">
            <div className="App-subtitle">
              {props.subtitle}
            </div>
          </subheader><br></br>
    </Grid>
);

Subheader.propTypes = {
     subtitle : PropTypes.string.isRequired,
};

Subheader.defaultProps = {
    subtitle: "Earnings Setup"
};

export default Subheader;
