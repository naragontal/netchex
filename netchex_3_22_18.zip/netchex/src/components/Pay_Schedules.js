import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';
import PropTypes from 'prop-types';
import  {
  Grid,
} from 'react-bootstrap';


import pay_schedules_icon from '../assets/pay_schedules_icon.png';
import grn_line from '../assets/grn_line_icon.png';

import Header from './Header';

import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

   const Pay_Schedules = (props) => (
      <Grid>
          <Header />
          <div className="App-subheader">
              <div className="App-subtitle">
                {props.subtitle}
              </div>
          </div><br></br>
          <main className="App-main">
             <div className="App-intro-title"><br></br>
                {props.intro_title}
             </div><br></br>
             <img src={pay_schedules_icon} className="App-success" alt="Pay Schedules Page" /><br></br>
             <div className="App-small-text">
               <scan className="App-intro"><b>{props.intro}</b><br></br></scan>
               <scan className="scan-center">{props.small_text_1}<br></br></scan>
             </div><br></br>
           </main><br></br>
           <footer className="App-footer-center"><br></br>
            <Link to="/" className="link-back" style={{ textDecoration: 'none' }}>{props.back_btn_text}</Link>
           </footer>
        </Grid>
      );

      Pay_Schedules.propTypes = {
         subtitle : PropTypes.string.isRequired,
         intro_title : PropTypes.string.isRequired,
         intro : PropTypes.string.isRequired,
         small_text_1 : PropTypes.string.isRequired,
         back_btn_text : PropTypes.string.isRequired,
      };

      Pay_Schedules.defaultProps = {
         subtitle : "Pay Schedules Setup",
         intro_title : "Welcome to Pay Schedules!",
         intro : "This page is under construction!",
         small_text_1: "Please come back next month",
         back_btn_text : "< BACK TO DASHBOARD",
      };

    export default Pay_Schedules;
