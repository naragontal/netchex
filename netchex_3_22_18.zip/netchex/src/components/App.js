import React from 'react';
import {
     BrowserRouter,
     Route
} from 'react-router-dom';


// import child components
import Home from './Home';
import Locations from './Locations';
import Pay_Schedules from './Pay_Schedules';
import Earnings from './Earnings';
import Uploads from './Uploads';


// import stylesheets
import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

   const App = () => (
     <BrowserRouter>
        <div className="container">
           <Route exact path="/" component={Home} />
           <Route path="/locations" component={Locations} />
           <Route path="/pay_schedules" component={Pay_Schedules} />
           <Route path="/earnings" component={Earnings} />
           <Route path="/uploads" component={Uploads} />
        </div>
     </BrowserRouter>
  );

export default App;
