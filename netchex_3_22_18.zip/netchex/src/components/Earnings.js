import React from 'react';
import { Route, Link, Redirect, BrowserRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import cta_green_arrow from '../assets/cta_green_arrow.png';
import earnings_icon from '../assets/earnings_icon.png';
import helpful_tips_icon from '../assets/helpful_tips_icon.png';
import payroll_betty_icon from '../assets/payroll_betty_icon.png';

import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

import Header from './Header';
import Subheader from './Subheader';
import Home from './Home';
import Earnings_Main from './Earnings';
import Earnings_Setup_1 from './earnings/Earnings_Setup_1';
import Earnings_Setup_2 from './earnings/Earnings_Setup_2';
import Earnings_Setup_3 from './earnings/Earnings_Setup_3';
import Earnings_Setup_4 from './earnings/Earnings_Setup_4';
import Earnings_Setup_5 from './earnings/Earnings_Setup_5';
import Earnings_Setup_6 from './earnings/Earnings_Setup_6';
import Earnings_Setup_Finish from './earnings/Earnings_Setup_Finish';

const Earnings = (props) => (
     <Grid>
       <Header />
        <Route exact path="/earnings" render={ () => <Redirect to="/earnings/Earnings_Setup_1" /> } />
        <Route path="/earnings/Earnings_Setup_1" component={Earnings_Setup_1} />
        <Route path="/earnings/Earnings_Setup_2" component={Earnings_Setup_2} />
        <Route path="/earnings/Earnings_Setup_3" component={Earnings_Setup_3} />
        <Route path="/earnings/Earnings_Setup_4" component={Earnings_Setup_4} />
        <Route path="/earnings/Earnings_Setup_5" component={Earnings_Setup_5} />
        <Route path="/earnings/Earnings_Setup_6" component={Earnings_Setup_6} />
        <Route path="/earnings/Earnings_Setup_Finish" component={Earnings_Setup_Finish} />
     </Grid>
);



export default Earnings;
