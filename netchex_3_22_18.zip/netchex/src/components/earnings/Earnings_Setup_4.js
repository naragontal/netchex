import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import PropTypes from 'prop-types';
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import payroll_betty_icon from '../../assets/payroll_betty_icon.png';
import success_icon from '../../assets/success_icon.png';
import blank_icon from '../../assets/blank_icon.png';
import grn_line_5 from '../../assets/grn_line_icon_5.png';

import '../../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

      const Earnings_Setup_4 = (props) => (
          <Grid>
             <div className="App-subheader2">
               <div className="App-subtitle">
                   {props.subtitle}
               </div>
             </div><br></br>
             <img src={grn_line_5} className="App-grn-line-2" alt="line" />
             <main className="App-main">

             <div className="App-intro-title-left"><br></br>
                {props.intro_title}
             </div><br></br>

             <div className="App-intro-left">
                 <scan>{props.intro_1}<br></br></scan>
             </div><br></br>
             <Grid>
             <Row className="show-grid">
             <Col xs={6} md={3}>
                <div className="btn-radio-yes">
                   <label>
                      <input type="radio" value="option1" checked={true} />
                        <scan className="App-radio-btn-text">{props.radio_1}</scan>
                   </label>
                </div>
                </Col>
                <Col xs={6} md={3}>
                <div className="btn-radio-no">
                   <label>
                      <input type="radio" value="option1" checked={false} />
                        <scan className="App-radio-btn-text">{props.radio_2}</scan>
                   </label>
                </div>
                </Col>
                </Row>
             </Grid><br></br>

             <div className="App-intro-left">
                 <scan>{props.intro_2}<br></br></scan>
             </div><br></br>

             <Grid>
             <Row className="show-grid">
               <Col xs={6} md={3}>
                 <div className="btn-grn-success"><br></br>
                   <a href=" " >
                     <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                        {props.setup_text_icons_1}<br></br>
                 </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-blank"><br></br>
               <a href=" " className="setup-text-icons">
                 <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                 <p className="setup-text-icons">{props.setup_text_icons_2}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-blank"><br></br>
                 <a href=" " className="setup-text-icons">
                   <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_2}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
                 <div className="btn-grn-success"><br></br>
                   <a href=" " >
                     <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                        {props.setup_text_icons_1}<br></br>
                 </div>
               </Col>
             </Row>
             </Grid><br></br>

            </main>
            <footer className="App-footer">
            <Grid>
            <Row className="show-grid">
              <Col sm={6} md={4}>
                <div className="footer-text ">
                <img src={payroll_betty_icon} className="App-betty" alt="line" />
                <scan>{props.betty_text}</scan>
                </div>
              </Col>
              <Col sm={6} md={4}>
              </Col>
              <Col sm={6} md={4}>
                <Link to="/earnings/Earnings_Setup_3" className="link-back" style={{ textDecoration: 'none' }}>{props.back_btn_text}</Link>
                <Link to="/earnings/Earnings_Setup_5" className="btn-continue2" style={{ textDecoration: 'none' }}>{props.continue_btn_text}</Link>
              </Col>
            </Row>
            </Grid>
            </footer>
        </Grid>
      );

      Earnings_Setup_4.propTypes = {
         subtitle : PropTypes.string.isRequired,
         intro_title : PropTypes.string.isRequired,
         intro_1 : PropTypes.string.isRequired,
         intro_2 : PropTypes.string.isRequired,
         radio_1 : PropTypes.string.isRequired,
         radio_2 : PropTypes.string.isRequired,
         setup_text_icons_1 : PropTypes.string.isRequired,
         setup_text_icons_2 : PropTypes.string.isRequired,
         betty_text : PropTypes.string.isRequired,
         back_btn_text : PropTypes.string.isRequired,
         continue_btn_text : PropTypes.string.isRequired
      };

      Earnings_Setup_4.defaultProps = {
         subtitle : "Earnings Setup",
         intro_title : "Accual Plans",
         intro_1 : "Do you have accrual plans?",
         intro_2 : "Which earnings do you want to add?",
         radio_1 : "Yes",
         radio_2 : "No",
         setup_text_icons_1 : "Paid Time Off",
         setup_text_icons_2 : "Personal",
         betty_text: "Accrual plans are...",
         back_btn_text : "< BACK",
         continue_btn_text : "CONTINUE"
      };


   export default Earnings_Setup_4;
