import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import PropTypes from 'prop-types';
import  {
  Grid,
  Row,
  Col
} from 'react-bootstrap';

import edit_icon from '../../assets/edit_icon.png';
import payroll_betty_icon from '../../assets/payroll_betty_icon.png';
import grn_line_7 from '../../assets/grn_line_icon_7.png';

import '../../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

     const Earnings_Setup_6 = (props) => (
         <Grid>
             <div className="App-subheader2">
               <div className="App-subtitle">
                   {props.subtitle}
               </div>
             </div><br></br>
             <img src={grn_line_7} className="App-grn-line-2" alt="line" />
             <main className="App-main">

             <div className="App-intro-title-left"><br></br>
                {props.intro_title}
             </div><br></br>

             <div className="App-intro-left">
                 <scan>{props.intro_1}<br></br></scan>
                 <scan>{props.intro_2}<br></br></scan>
             </div><br></br>
             <Grid>
             <div className="App-table-div">
             <Row className="show-grid" >
               <Col xs={3} md={4}>
                   <div className="App-table-text">
                       <p><b>Base Earnings</b><img src={edit_icon} className="App-edit-icon" alt="edit" /><br></br>
                       Holiday<br></br>
                       Jury Duty<br></br>
                       Overtime<br></br>
                       Regular<br></br></p>
                    </div>
              </Col>
              <Col xs={3} md={4}>
                  <div className="App-table-text">
                     <p><b>Accruals</b><img src={edit_icon} className="App-edit-icon" alt="edit" /><br></br>
                     Paid Time Off<br></br>
                     Vacation<br></br>
                     <br></br>
                     <br></br></p>
                  </div>
              </Col>
              <Col xsHidden md={4}>
                    <div className="App-table-text">
                     <p><b>Tips</b><img src={edit_icon} className="App-edit-icon" alt="edit" /><br></br>
                     Tips Shortfall/<br></br>
                     Makeup<br></br>
                     <br></br>
                     <br></br></p>
                    </div>
              </Col>
              </Row>
              </div>
             </Grid>
            </main>
            <footer className="App-footer">
            <Grid>
            <Row className="show-grid">
              <Col sm={6} md={4}>
                <div className="footer-text ">
                <img src={payroll_betty_icon} className="App-betty" alt="line" />
                <scan>{props.betty_text}</scan>
                </div>
              </Col>
              <Col sm={6} md={4}>
              </Col>
              <Col sm={6} md={4}>
               <Link to="/earnings/Earnings_Setup_5" className="link-back" style={{ textDecoration: 'none' }}>{props.back_btn_text}</Link>
               <Link to="/earnings/Earnings_Setup_Finish" className="btn-custom" style={{ textDecoration: 'none' }}>{props.looks_good_btn_text}</Link>
              </Col>
            </Row>
            </Grid>
            </footer>
        </Grid>
      );

      Earnings_Setup_6.propTypes = {
         subtitle : PropTypes.string.isRequired,
         intro_title : PropTypes.string.isRequired,
         intro_1  : PropTypes.string.isRequired,
         intro_2  : PropTypes.string.isRequired,
         betty_text : PropTypes.string.isRequired,
         back_btn_text : PropTypes.string.isRequired,
         looks_good_btn_text : PropTypes.string.isRequired
      };

      Earnings_Setup_6.defaultProps = {
         subtitle : "Earnings Setup",
         intro_title : "Alright, here is what we have so far...",
         intro_1 : "Take a look at what we have for your earnings setup. You will have more customizable",
         intro_2 : "options within Netchex once your company is created.",
         betty_text: "Based on this information we will be able to...",
         back_btn_text : "< BACK",
         looks_good_btn_text : "LOOKS GOOD"
      };

   export default Earnings_Setup_6;
