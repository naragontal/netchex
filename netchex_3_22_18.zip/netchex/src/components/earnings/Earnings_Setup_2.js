import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import PropTypes from 'prop-types';
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import payroll_betty_icon from '../../assets/payroll_betty_icon.png';
import blank_icon from '../../assets/blank_icon.png';
import success_icon from '../../assets/success_icon.png';
import grn_line_3 from '../../assets/grn_line_icon_3.png';

import '../../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

    const Earnings_Setup_2 = (props) => (
        <Grid>
             <div className="App-subheader2">
               <div className="App-subtitle">
                   {props.subtitle}
               </div>
             </div><br></br>
             <img src={grn_line_3} className="App-grn-line-2" alt="line" />
             <main className="App-main">

             <div className="App-intro-title-left"><br></br>
               {props.intro_title}
             </div>

             <div className="App-intro-left">
                 <scan>{props.intro}<br></br></scan>
             </div><br></br>

             <Grid>
             <Row className="show-grid">
               <Col xs={6} md={3} >
               <div className="btn-blank"><br></br>
                <a href=" " className="setup-text-icons">
                  <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                  <p className="setup-text-icons">{props.setup_text_icons_1}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-blank"><br></br>
               <a href=" " className="setup-text-icons">
                 <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                 <p className="setup-text-icons">{props.setup_text_icons_2}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-blank"><br></br>
                 <a href=" " className="setup-text-icons">
                   <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_3}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
                 <div className="btn-grn-success"><br></br>
                   <a href=" " >
                     <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                     <p className="setup-text-icons">{props.setup_text_icons_4}</p><br></br>
                 </div>
               </Col>
             </Row><br></br>

             <Row className="show-grid">
               <Col xs={6} md={3}>
               <div className="btn-grn-success"><br></br>
                 <a href=" " >
                   <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_5}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-grn-success"><br></br>
                 <a href=" " >
                   <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_6}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-grn-success"><br></br>
                 <a href=" " >
                   <img src={success_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_7}</p><br></br>
               </div>
               </Col>
               <Col xs={6} md={3}>
               <div className="btn-blank"><br></br>
                 <a href=" " className="setup-text-icons">
                   <img src={blank_icon} className="App-success-small" alt="line" /><br></br></a>
                   <p className="setup-text-icons">{props.setup_text_icons_8}</p><br></br>
               </div>
               </Col>
             </Row>
             </Grid><br></br>

            </main>
            <footer className="App-footer">
            <Grid>
            <Row className="show-grid">
              <Col sm={6} md={4}>
                <div className="footer-text ">
                <img src={payroll_betty_icon} className="App-betty" alt="line" />
                <scan className="betty-text">{props.betty_text_1}</scan><br></br>
                <scan className="betty-text2">{props.betty_text_2}</scan>
                </div>
              </Col>
              <Col sm={6} md={4}>
              </Col>
              <Col sm={6} md={4}>
                <Link to="/earnings/Earnings_Setup_1" className="link-back" style={{ textDecoration: 'none' }}>{props.back_btn_text}</Link>
                <Link to="/earnings/Earnings_Setup_3" className="btn-continue2" style={{ textDecoration: 'none' }}>{props.continue_btn_text}</Link>
              </Col>
            </Row>
            </Grid>
            </footer>
        </Grid>
    );

    Earnings_Setup_2.propTypes = {
       subtitle : PropTypes.string.isRequired,
       intro_title : PropTypes.string.isRequired,
       intro : PropTypes.string.isRequired,
       setup_text_icons_1 : PropTypes.string.isRequired,
       setup_text_icons_2 : PropTypes.string.isRequired,
       setup_text_icons_3 : PropTypes.string.isRequired,
       setup_text_icons_4 : PropTypes.string.isRequired,
       setup_text_icons_5 : PropTypes.string.isRequired,
       setup_text_icons_6 : PropTypes.string.isRequired,
       setup_text_icons_7 : PropTypes.string.isRequired,
       setup_text_icons_8 : PropTypes.string.isRequired,
       betty_text_1 : PropTypes.string.isRequired,
       betty_text_2 : PropTypes.string.isRequired,
       back_btn_text : PropTypes.string.isRequired,
       continue_btn_text : PropTypes.string.isRequired
    };

    Earnings_Setup_2.defaultProps = {
       subtitle : "Earnings Setup",
       intro_title : "Choose base earnings",
       intro : "Select from the list of earnings below ones you would like to add to your company.",
       setup_text_icons_1 : "Bereavement",
       setup_text_icons_2 : "Bonus",
       setup_text_icons_3 : "Commission",
       setup_text_icons_4 : "Holiday",
       setup_text_icons_5 : "Jury Duty",
       setup_text_icons_6 : "Overtime",
       setup_text_icons_7 : "Regular",
       setup_text_icons_8 : "Other",
       betty_text_1 : "Holiday, Overtime, and Regular earnings will be added",
       betty_text_2 : "to your company by default.",
       back_btn_text : "< BACK",
       continue_btn_text : "CONTINUE"
    };

   export default Earnings_Setup_2;
