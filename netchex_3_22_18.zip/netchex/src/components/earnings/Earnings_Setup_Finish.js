import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom'
import PropTypes from 'prop-types';
import  {
  Grid,
} from 'react-bootstrap';

import success_icon from '../../assets/success_icon.png';
import grn_line from '../../assets/grn_line_icon.png';

import '../../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

   const Earnings_Setup_Finish = (props) => (
      <Grid>
          <div className="App-subheader2">
              <div className="App-subtitle">
                {props.subtitle}
              </div>
          </div><br></br>
          <img src={grn_line} className="App-grn-line" alt="line" />
          <main className="App-main">
             <div className="App-intro-title"><br></br>
                {props.intro_title}
             </div><br></br>
             <img src={success_icon} className="App-success" alt="Success" /><br></br>
             <div className="App-small-text">
               <scan className="App-intro"><b>{props.intro}</b><br></br></scan>
               <scan className="scan-center">{props.small_text_1}<br></br></scan>
               <scan className="scan-center">{props.small_text_2}<br></br></scan>
             </div><br></br>
           </main><br></br>
           <footer className="App-footer-center"><br></br>
             <Link to="/earnings/Earnings_Setup_6" className="link-back" style={{ textDecoration: 'none' }}>{props.back_btn_text}</Link>
             <Link to="/" className="btn-continue2" style={{ textDecoration: 'none' }}>{props.continue_btn_text}</Link>
           </footer>
        </Grid>
      );

      Earnings_Setup_Finish.propTypes = {
         subtitle : PropTypes.string.isRequired,
         intro_title : PropTypes.string.isRequired,
         intro : PropTypes.string.isRequired,
         small_text_1 : PropTypes.string.isRequired,
         small_text_2 : PropTypes.string.isRequired,
         back_btn_text : PropTypes.string.isRequired,
         continue_btn_text : PropTypes.string.isRequired
      };

      Earnings_Setup_Finish.defaultProps = {
         subtitle : "Earnings Setup",
         intro_title : "Earnings Setup Complete!",
         intro : "Up Next: Deductions",
         small_text_1: "If employees live in a different state than the",
         small_text_2 : "company locations, tell us the states.",
         back_btn_text : "< BACK",
         continue_btn_text : "CONTINUE"
      };

    export default Earnings_Setup_Finish;
