import React from 'react';
import { Route, Link, Redirect, BrowserRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import cta_green_arrow from '../../assets/cta_green_arrow.png';
import earnings_icon from '../../assets/earnings_icon.png';
import helpful_tips_icon from '../../assets/helpful_tips_icon.png';
import payroll_betty_icon from '../../assets/payroll_betty_icon.png';

import '../../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

import Header from '../Header';
import Subheader from '../Subheader';
import Home from '../Home';


const Earnings_Setup_1 = (props) => (
     <Grid>
     <Row className="show-grid">
         <Col lg={8} md={6} className="App-column-left">
            <div className="dashboard-text-title"><br></br>
               <Link to="/" className="link-back" style={{ textDecoration: 'none' }}>{props.dashboard_title}</Link>
            </div>

            <div className="App-intro-title-left2"><br></br>
               <img src={earnings_icon} className="App-setup-icons2" alt="Earnings" />
               <p className="App-intro-title-left">{props.intro_title}</p>
               <p className="App-intro-left">{props.intro}</p>
            </div><br></br>
            <div className="btn-blank-earnings-setup1"><br></br>
             <Link to="/earnings/Earnings_Setup_2">
               <img src={cta_green_arrow} className="App-setup-icons3" alt="Earnings" /></Link><br></br>
               <p className="earnings-text">{props.earnings_text_lg}</p>
               <p className="earnings-text-small">{props.earnings_text_sm}</p><br></br>
            </div>
        </Col>
        <Col lg={3} md={4}>
            <div className="App-small-text-left"><br></br>
                <img src={helpful_tips_icon} className="App-helpful-tips" alt="Helpful tips" />
                <p className="App-small-text"><b>{props.helpful_tips_title}</b></p>
                <img src={payroll_betty_icon} className="App-betty2" alt="line" /><p className="App-small-text-left2">{props.betty_title}<br></br></p>
                <p className="App-small-text-left2">...<br></br>
                     Our main goal is to find out if you have more<br></br>
                     than one physical location to make sure we<br></br>
                     setup taxes correctly if the location are in more<br></br>
                     than one state.
                </p>
            </div>
        </Col>
    </Row>
  </Grid>
);

Earnings_Setup_1.propTypes = {
   dashboard_title : PropTypes.string.isRequired,
   intro_title : PropTypes.string.isRequired,
   intro : PropTypes.string.isRequired,
   earnings_text_lg : PropTypes.string.isRequired,
   earnings_text_sm : PropTypes.string.isRequired,
   helpful_tips_title : PropTypes.string.isRequired,
   betty_title : PropTypes.string.isRequired
 };

 Earnings_Setup_1.defaultProps = {
   dashboard_title : "< Dashboard",
   intro_title : "Earnings Setup",
   intro : "Below are the essential items needed to get you running your first payroll.",
   earnings_text_lg : "1. Earnings Setup",
   earnings_text_sm : "Lets get a base set of earnings used for your company.",
   helpful_tips_title : "Helpful Tips",
   betty_title : "Payroll Betty"
 };

export default Earnings_Setup_1;
