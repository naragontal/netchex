import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
  BrowserRouter as Router,
  Route,
  NavLink
} from 'react-router-dom'
import  {
  Grid,
  Row,
  Col,
} from 'react-bootstrap';

import netchex_logo from '../assets/netchex_logo.png';

import '../css/App.css';
import 'bootstrap/dist/css/bootstrap.css';

const Header = (props) => (
    <Grid>
        <header className="App-header">
            <div className="App-title">
                <img src={netchex_logo} className="App-logo" alt="logo" />
                   {props.title}
             </div>
        </header>
    </Grid>
);

Header.propTypes = {
     title : PropTypes.string.isRequired,
};

Header.defaultProps = {
    title: "Company Setup"
};

export default Header;
